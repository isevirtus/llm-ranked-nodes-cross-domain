# Confidence-guided Bayesian network parameterization

Replication package for **Confidence-Guided Bayesian Network Parameterization with Language Models and Ranked Nodes: An Exploratory Study Across Two Domains**, prepared for ACM SAC 2027, Machine Learning and Its Application (MLA) track.

**Status:** private author repository during double-blind review. This is an exploratory, single-run experiment. It contains two networks, two Qwen3.5 model sizes, four generation conditions per model/network, and two derived persona pools per model/network. It contains no gasifier results and no FullDist-only or RN-only experimental arm. No new LLM generations were run while assembling this package.

## Reproduce the numerical results

Requires Python 3.10 or newer; no GPU, network, API key, R installation, or third-party Python library is needed for the archived-results analysis.

```sh
python scripts/reproduce.py
```

The command checks all 13 original-file SHA-256 hashes, the generation and reference hashes, probability validity, state/parent alignment, and all 24 evaluated networks. It reads original generation CPTs, reconstructs both persona pools, compares every probability to the original evaluator export, and recomputes MAE, RMSE, mean total variation, smoothed mean CPT KL, and weighted BN KL. It adds a uniform baseline per domain. Successful execution ends with `PASS` and writes `results/verification.json`.

**Verification boundary:** weighted BN KL reuses the original evaluator's reference-parent marginal probabilities after checking their normalization. It does not independently rerun bnRep inference. Reference files and the original V5 evaluator are preserved for that separate reproduction path. Small reference row-sum rounding effects can yield differences below 1e-7; the checker reports the maximum metric discrepancy.

To regenerate publication figures and tables:

```sh
python -m pip install -r requirements-analysis.txt
python scripts/paper_artifacts.py
```

Compile `paper/main.tex` with pdfLaTeX and BibTeX (or `latexmk -pdf main.tex` from `paper/`). The Overleaf upload archive contains the complete paper source, generated tables and PDF figures. It does not require running Python in Overleaf.

## Contents

| Path | Purpose |
|---|---|
| `data/original/` | Eight unchanged ZIP archives: four generation and four evaluation archives |
| `notebooks/original/` | Four unchanged generation notebooks and the V5 evaluator |
| `data/provenance.json`, `SHA256SUMS` | Original Drive sources, sizes, and integrity hashes |
| `docs/protocol.md` | Retrospectively reconstructed executed protocol and unresolved details |
| `docs/reproduction.md` | Archived reanalysis, fresh generation, and original evaluator instructions |
| `docs/claims.md` | Paper claims mapped to generated tables and source artifacts |
| `docs/limitations.md` | Scope, missing controls, and replication limitations |
| `results/` | Recomputed metrics, routing, row/node diagnostics, and verification report |
| `paper/` | Anonymous MLA manuscript, bibliography, generated tables and figures |
| `.github/workflows/reproduce.yml` | Dependency-free numerical reproduction on Python 3.11 |

## Main observations

- Seismic: 9B has lower MAE in five of six matched conditions, while 4B's equal pool has the lowest observed BN KL.
- Electricvehicle: 4B has lower MAE and mean CPT KL in all six matched conditions. All twelve model/condition outputs have worse mean CPT KL than uniform probabilities.
- Most conditional rows are completed by RN. Every conditional row in the three seismic 4B persona runs uses unanchored RN defaults plus the model's qualitative direction hints.
- Equal and configured-weight pools do not uniformly improve the no-persona control. Pools combine three persona networks and exclude the control; they are not independent replications.

These observations measure agreement with archived benchmark parameters, not observed-event calibration, causal effectiveness of routing, operational safety, or general model quality.

## Review and reuse

The paper omits the identifying repository URL and author details. Do not provide this organization URL as an anonymous reviewer artifact. The original archives may contain source paths, names, and notebook metadata; produce and inspect a separate anonymized artifact before sharing with reviewers.

Original study artifacts retain their existing rights. No blanket license is asserted for the authors' manuscript or original notebooks. See `THIRD_PARTY_NOTICES.md` for bnRep and ACM template attribution. Model weights are not included. The previous software-engineering manuscript is backed up separately and is not part of this replication package.
