# Executed protocol reconstructed from artifacts

This document was assembled on 2026-10-16 from original notebooks, generation manifests, raw responses, CPTs, and V5 evaluation archives. It is **retrospective documentation**, not a preregistration. Selection rationales and the timing of parameter choices cannot be established from these artifacts.

## Sample and conditions

- bnRep `seismic`: 10 nodes, 12 edges, 4 roots, 6 conditional nodes; 82 rows and 246 probabilities per complete network. Three states per variable.
- bnRep `electricvehicle`: 23 nodes, 22 edges, 15 roots, 8 conditional nodes; 79 rows and 158 probabilities. Binary variables, ordered no < yes in the generation input as a modeling assumption.
- Qwen/Qwen3.5-4B and Qwen/Qwen3.5-9B. Four separately generated conditions: no-persona control and three personas. One repetition, r1, for each cell. All cells use ConfidenceRankedNodes; the control is not a direct-only baseline.
- Seismic personas: structural engineer, seismologist, probabilistic risk analyst. Electricvehicle personas: electric vehicle systems engineer, automotive fire safety and reliability specialist, probabilistic risk analyst.
- Generation occurred 2026-10-03 through 2026-10-10 UTC, according to manifests. V5 evaluations were produced on 2026-10-14. The uniform baseline and the independent reanalysis are post-hoc additions on 2026-10-16.

## Inputs and isolation

The `rede_original.json` files specify a fixed graph, node definitions, states, and qualitative context. `personas_original.json` supplies role instructions and pooling weights. The generator does not call bnRep or consume reference CPTs; the evaluator loads references separately. This code-level separation does not rule out benchmark memorization or semantic differences between elicitation descriptions and source models. A preliminary name-only familiarity question is archived; self-report is not a contamination test.

## Hybrid construction

1. Elicit root distributions directly using FullDist (a tuple in the specified state order).
2. For each eligible conditional node, ask for a confidence score in [0,1] for every parent configuration and a positive/negative/uncertain influence label per parent. Confidence is explicitly defined as perceived relevant internal knowledge for estimating the full distribution.
3. Elicit FullDist only for conditional rows with confidence >=0.80. Keep those distributions as the final output on the selected rows; also use them as fitting anchors.
4. Complete other rows with a midpoint WMEAN ranked-node approximation. States partition [0,1] equally; parent states are represented by interval midpoints. Negative directions reverse the midpoint; uncertain directions default to positive in the implementation. The weighted mean defines the location of a normal distribution truncated to [0,1], integrated over child-state intervals.
5. With anchors, fit softmax weights and sigma by confidence-weighted squared Hellinger loss plus 0.02 times squared distance from equal weights. L-BFGS-B uses up to 500 iterations, log-weight bounds [-6,6], and sigma bounds [0.03,0.45]. Direction combinations are enumerated when anchor count >= max(2, parent_count+1) and parent_count <=6; otherwise qualitative hints are fixed.
6. With no anchors, use equal weights and sigma=0.16, retaining the qualitative direction hints. This is distinct from the uniform-distribution fallback. Archives report no rows marked as fallback uniform.

This midpoint WMEAN implementation is narrower than RNM implementations using parent-interval integration or several aggregation families. It must not be described as testing all RNM variants.

## Execution settings

Manifests record 4-bit quantization, temperature 0.1, base seed 42, and disabled thinking. The code derives per-call seeds from a hash and the base seed. Requested model revision is `main`; `modelo_commit_carregado` is null. A reproducible exact model snapshot is therefore unavailable. Generation notebooks install development dependencies and are preserved unchanged rather than represented as a fully locked environment.

Recorded limits include 2048 FullDist output tokens (4096 retry), 1536 confidence-screen output tokens, five general retries, and four confidence parsing attempts. Consult the original notebook and per-call/parser logs for exact execution behavior. A configured fixed seed does not by itself guarantee bitwise reproducibility across devices or software versions.

## Persona pooling

Pool only the three persona networks, excluding the control, separately for each domain and model. Equal pooling assigns 1/3 to each persona. Weighted pooling uses 0.5/0.3/0.2 in persona order. Seismic overrides: SeismicHazard 0.15/0.70/0.15; Fragility 0.70/0.10/0.20. No performance-learning procedure for these weights is established. Pools are deterministic combinations, not new LLM calls or replications.

## Evaluation

References are archived bnRep 0.0.6 BIF/CSV exports, with bnlearn 5.2.1 and R 4.6.1 recorded by the evaluator. Match node names, child-state names, and each parent name/state pair, not array positions. Electricvehicle requires state reversals and parent-order reconciliation. The two model sizes use the same reference BIF hash per domain.

Compute scalar MAE and RMSE, equal-row TV and CPT KL, and weighted BN KL. KL adds 1e-8 to each normalized state probability and renormalizes both distributions, with log base 2. Weighted BN KL sums row KL multiplied by the corresponding reference parent-configuration marginal. Because local KL is smoothed while the parent weights come from the archived reference, report this as the evaluator's smoothed weighted BN KL score rather than an exact unsmoothed joint KL. No p-values or confidence intervals are justified by the single run per cell; CPT rows are not independent replications.

## Unknown or untested

The original written protocol, rationale/preselection for thresholds and weights, exact model commits, repeated seeds, FullDist-only and RN-only controls, downstream decision performance, and gasifier output are absent. Do not fill these gaps with assumptions. The package supports exact archived-result reproduction; fresh generation remains a separate experiment.
