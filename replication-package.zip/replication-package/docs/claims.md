# Claim-to-evidence map

| Manuscript statement | Regenerated evidence | Original provenance |
|---|---|---|
| 16 generated networks and 8 derived pools; one r1 per cell | `results/audit.csv`, `verification.json` | four `manifesto_geracao.json` files |
| Two domains with 82/79 rows and 246/158 probabilities | `results/audit.csv` | `CPTs_originais_bnRep.csv`, network inputs |
| 9B lower seismic MAE in 5/6 matched conditions | `results/summary.csv` | generation CPDs and reference CSV |
| 4B lower electricvehicle MAE and CPT KL in 6/6 | `results/summary.csv` | same |
| Electricvehicle uniform CPT KL 0.6087 versus best hybrid 0.7895 | `results/summary.csv` | post-hoc uniform baseline from frozen reference |
| Every seismic 4B persona conditional row uses RN | `results/routing.csv` | generation `detalhes/*.json` |
| High-confidence FullDist rows can have large error | `results/direct_conditional.csv`, `by_row.csv`, `extreme_predictions.csv` | confidence/source metadata and aligned probabilities |
| Equal pooling does not always improve control | `results/summary.csv` | pool recomputed from three persona predictions |
| No uniform fallback rows recorded | `results/routing.csv` and original `resumo_hibrido.csv` | original generation metadata |
| Correct numerical alignment | `results/audit.csv` | every generation probability checked by name against evaluator export |

Mean CPT KL and weighted BN KL are different aggregations. Do not pool raw BN KL across networks of different sizes. TV is dimension-comparable; scalar MAE depends on the number of states. Uniform does not dominate every metric. Metrics express agreement with benchmark parameters, not empirical calibration or actual fire/seismic risk.
