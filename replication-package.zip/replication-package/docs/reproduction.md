# Reproduction paths

## A. Offline numerical reproduction (recommended first)

From the repository root run `python scripts/reproduce.py`. It uses Python's standard library only. Results are regenerated in `results/`. To avoid changing tracked results, use `python scripts/reproduce.py --output-dir /path/to/scratch-results`.

The script verifies the archived inputs before analysis. It never extracts an arbitrary ZIP to disk, never imports or executes notebook cells, and never loads model weights. It reconstructs persona pools from the original JSON and uses reference CSVs and archived reference-parent marginal weights. `results/verification.json` states this boundary explicitly.

## B. Figures and manuscript

Install `requirements-analysis.txt`, then run `python scripts/paper_artifacts.py`. Open `paper/main.tex` in Overleaf or compile using pdfLaTeX/BibTeX. Figures are generated from recomputed metrics, not manually transcribed values. The manuscript remains anonymous and omits the private repository URL.

## C. Fresh LLM generation

1. Select the original generator in `notebooks/original/` matching the domain and model size.
2. Use Google Colab with a suitable CUDA GPU, as expected by the notebook. The notebook installs dependencies and downloads model weights; this is a separate compute operation.
3. Take `rede_original.json` and `personas_original.json` from the corresponding original generation ZIP. Upload them using the notebook's input step. Do not provide evaluator reference files to the generator.
4. Inspect the model, quantization, seed, temperature, and confidence threshold before running. Preserve defaults to approximate the original experiment, but record the actual model commit and all dependency versions for a new run.
5. Save the resulting ZIP under a new name. Never overwrite the original archive or claim the new run is the original r1.

Exact regeneration is not guaranteed: requested model revision was `main`, the loaded commit was not recorded, and development package installation is not fully pinned. Archived-result reproduction is the stable path.

## D. Original V5 evaluation

Open `notebooks/original/evaluate_v5.ipynb` in Colab. Upload exactly one original generation ZIP and, optionally, the archived reference BIF from that domain's evaluation ZIP. Follow its reference setup and alignment steps. The notebook can download/install R/Python dependencies and obtain bnRep. To compare historical results, use the supplied reference hash and recorded version information, not an unrecorded newer reference. Retain all alignment audits and report any version drift.

For the two original domains, evaluation ZIPs already preserve BIF, RDS, R export script, R version records, and alignment reports. The independent runner uses these frozen evaluation exports without calling R.
