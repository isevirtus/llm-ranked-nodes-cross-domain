# Third-party notices

## bnRep

Evaluation archives include reference networks exported from **bnRep 0.0.6**, by Manuele Leonelli and contributors. The CRAN package declares `MIT + file LICENSE`; its LICENSE identifies `YEAR: 2024`, `COPYRIGHT HOLDER: bnRep authors`.

Source: https://github.com/manueleleonelli/bnRep

Reference: Manuele Leonelli (2025), *bnRep: A repository of Bayesian networks from the academic literature*, Neurocomputing 624, 129502. https://doi.org/10.1016/j.neucom.2025.129502

The networks originate in the publications cited in the manuscript: Roy et al. for seismic and Chen et al. for electricvehicle. Their contextual parameters are used as reference models, not as observed experimental outcomes.

MIT license notice for the bnRep materials:

Copyright (c) 2024 bnRep authors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## ACM manuscript template

`paper/acmart.cls` and `paper/ACM-Reference-Format.bst` are preserved from the supplied Overleaf project. Their embedded copyright and license notices remain intact. They are not authored by this study.

## Original study artifacts and models

Original notebooks, input descriptions, prompts, logs, and manuscript remain under their existing rights; this repository does not assign a new blanket license. No model weights are distributed. Fresh generation is subject to the selected model and dependency terms.
