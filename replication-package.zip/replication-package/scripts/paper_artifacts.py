"""Generate manuscript tables and vector figures from reproduce.py outputs."""
import csv
import json
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def read(name):
    with (ROOT/'results'/name).open(encoding='utf-8') as f: return list(csv.DictReader(f))
conditions={
 'seismic':['controle','engenheiro_estrutural','sismologista','analista_risco','ensemble_iguais','ensemble_ponderados'],
 'electricvehicle':['controle','engenheiro_veiculos_eletricos','especialista_seguranca_automotiva','analista_risco','ensemble_iguais','ensemble_ponderados']}
labels=['Control','Persona 1','Persona 2','Persona 3','Equal pool','Weighted pool']
summary={(r['domain'],r['model'],r['condition']):r for r in read('summary.csv')}
for domain in conditions:
    lines=[r'\begin{tabular}{lrrrrrr}',r'\toprule',r'& \multicolumn{3}{c}{Qwen3.5-4B} & \multicolumn{3}{c}{Qwen3.5-9B} \\',r'Condition & BN KL & CPT KL & TV & BN KL & CPT KL & TV \\',r'\midrule']
    for condition,label in zip(conditions[domain],labels):
        values=[float(summary[domain,m,condition][metric]) for m in ['4b','9b'] for metric in ['BN_KL_bits','CPT_KL_media_bits','TVD_media']]
        lines.append(label+' & '+' & '.join(f'{x:.4f}' for x in values)+r' \\')
    r=summary[domain,'none','uniform']
    vals=' & '.join(f'{float(r[k]):.4f}' for k in ['BN_KL_bits','CPT_KL_media_bits','TVD_media'])
    lines += [r'\midrule','Uniform & '+vals+' & '+vals+r' \\',r'\bottomrule',r'\end{tabular}']
    (ROOT/'paper/tables'/f'{domain}.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
groups=defaultdict(list)
for r in read('by_row.csv'):
    if r['source']=='LLM_FULLDIST': groups[r['domain'],r['model'],r['condition']].append(r)
direct=[]
all_rows=read('by_row.csv')
for (d,m,c),rs in groups.items():
    total=sum(float(r['CPT_KL_bits']) for r in all_rows if (r['domain'],r['model'],r['condition'])==(d,m,c))
    direct.append(dict(domain=d,model=m,condition=c,n_rows=len(rs),mean_confidence=sum(float(r['confidence']) for r in rs)/len(rs),mean_TVD=sum(float(r['TVD']) for r in rs)/len(rs),mean_CPT_KL=sum(float(r['CPT_KL_bits']) for r in rs)/len(rs),fraction_CPT_KL=sum(float(r['CPT_KL_bits']) for r in rs)/total))
with (ROOT/'results/direct_conditional.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(direct[0]));w.writeheader();w.writerows(direct)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'ps.fonttype':42})
colors={'4b':'#176B87','9b':'#B34B27'}
fig,axes=plt.subplots(1,2,figsize=(7,2.35),layout='constrained')
for ax,d in zip(axes,conditions):
    for m,marker in [('4b','o'),('9b','s')]:
        ax.plot(range(6),[float(summary[d,m,c]['CPT_KL_media_bits']) for c in conditions[d]],label=m.upper(),marker=marker,color=colors[m],linewidth=1.4,markersize=4)
    ax.axhline(float(summary[d,'none','uniform']['CPT_KL_media_bits']),color='#555555',ls='--',lw=1,label='Uniform')
    ax.set_xticks(range(6),['C','P1','P2','P3','Equal','Weighted'])
    ax.set_title('Seismic' if d=='seismic' else 'Electric vehicle')
    ax.set_ylabel('Mean CPT KL (bits; lower is better)')
    ax.spines[['right','top']].set_visible(False)
    ax.grid(axis='y',alpha=.18);ax.set_ylim(bottom=0)
axes[0].legend(frameon=False,ncol=3,fontsize=7)
fig.savefig(ROOT/'paper/figures/cpt_kl.pdf');fig.savefig(ROOT/'paper/figures/cpt_kl.png',dpi=180)
plt.close(fig)
route=read('routing.csv')
fig,axes=plt.subplots(1,2,figsize=(7,2.2),layout='constrained')
for ax,d in zip(axes,conditions):
    for m,offset in [('4b',-.18),('9b',.18)]:
        vals=[next(int(r['conditional_fullDist']) for r in route if (r['domain'],r['model'],r['condition'])==(d,m,c)) for c in conditions[d][:4]]
        bars=ax.bar([x+offset for x in range(4)],vals,width=.34,label=m.upper(),color=colors[m])
        ax.bar_label(bars,padding=2,fontsize=7)
    ax.set_xticks(range(4),['Control','P1','P2','P3'])
    ax.set_title(('Seismic: 78 conditional rows' if d=='seismic' else 'Electric vehicle: 64 conditional rows'))
    ax.set_ylabel('Rows selected for direct elicitation')
    ax.set_ylim(0,27);ax.spines[['right','top']].set_visible(False)
    ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
axes[0].legend(frameon=False,ncol=2,fontsize=7)
fig.savefig(ROOT/'paper/figures/routing.pdf');fig.savefig(ROOT/'paper/figures/routing.png',dpi=180)
print('Generated 2 LaTeX tables, 2 PDF/PNG figures, and direct_conditional.csv')
