"""Offline reproduction from archived generation JSON and evaluator reference exports.

Python >=3.10; standard library only. Never calls an LLM or downloads data.
BN KL uses archived reference-parent marginal weights; this is explicit in the audit.
"""
import argparse
import csv
import hashlib
import io
import itertools
import json
import math
from collections import defaultdict
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EPS = 1e-8

def read_csv(z, name):
    return list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8-sig'))))

def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def key(node, parents):
    return node, tuple(sorted(parents.items()))

def distribution(values):
    assert values and all(math.isfinite(p) and p >= 0 for p in values)
    assert abs(sum(values)-1) < 1e-6, sum(values)
    return [p/sum(values) for p in values]

def kl(p, q):
    p, q = distribution(p), distribution(q)
    p = [(x+EPS)/(1+len(p)*EPS) for x in p]
    q = [(x+EPS)/(1+len(q)*EPS) for x in q]
    return sum(a*math.log2(a/b) for a,b in zip(p,q))

def decode_cpds(obj):
    result = {}
    for node, c in obj['cpds'].items():
        assert c['variables'][0] == node
        parents = c['variables'][1:]
        configs = list(itertools.product(*(c['state_names'][p] for p in parents)))
        assert len(c['values']) == len(c['state_names'][node])
        assert all(len(v)==len(configs) for v in c['values'])
        for col, config in enumerate(configs):
            vals = [v[col] for v in c['values']]
            distribution(vals)
            result[key(node,dict(zip(parents,config)))] = dict(zip(c['state_names'][node],vals))
    return result

def combine(predictions, personas, weights_by_node, equal=False):
    out = {}
    for k, states in next(iter(predictions.values())).items():
        weights = {p['id']:1 if equal else p['peso'] for p in personas}
        if not equal and k[0] in weights_by_node:
            weights = weights_by_node[k[0]]
        total = sum(weights.values())
        assert total > 0
        out[k] = {s:sum(weights[pid]*predictions[pid][k][s] for pid in weights)/total for s in states}
    return out

def score(ref, pred, parent_weights):
    assert set(ref)==set(pred)
    abs_err, sq_err, tv, ks = [], [], [], []
    bn = 0
    for k, states in ref.items():
        assert set(states)==set(pred[k])
        p, q = list(states.values()), [pred[k][s] for s in states]
        distribution(p); distribution(q)
        differences = [abs(a-b) for a,b in zip(p,q)]
        abs_err.extend(differences)
        sq_err.extend(d*d for d in differences)
        tv.append(sum(differences)/2)
        ks.append(kl(p,q))
        bn += ks[-1]*parent_weights[k]
    return dict(BN_KL_bits=bn,CPT_KL_media_bits=sum(ks)/len(ks),MAE=sum(abs_err)/len(abs_err),RMSE=math.sqrt(sum(sq_err)/len(sq_err)),TVD_media=sum(tv)/len(tv))

def run(out):
    out.mkdir(parents=True,exist_ok=True)
    provenance=json.loads((ROOT/'data/provenance.json').read_text(encoding='utf-8'))
    for record in provenance['files']:
        assert hashlib.sha256((ROOT/record['path']).read_bytes()).hexdigest()==record['sha256'], record['path']
    summary, routing, node_rows, confidence, audit, extremes, marginal_rows = [], [], [], [], [], [], []
    reference_hashes={}
    for domain, model in itertools.product(['seismic','electricvehicle'],['4b','9b']):
        stem=f'{domain}_qwen35_{model}'
        with zipfile.ZipFile(ROOT/'data/original'/f'{stem}_generation.zip') as gen, zipfile.ZipFile(ROOT/'data/original'/f'{stem}_evaluation.zip') as eva:
            manifest=json.loads(gen.read('manifesto_geracao.json'))
            cfg=manifest['configuracao']
            assert cfg['repeticoes']==1 and cfg['limiar_confianca']==0.8
            evmanifest=json.loads(eva.read('manifesto_avaliacao.json'))
            assert evmanifest['sha256_manifesto_geracao']==hashlib.sha256(gen.read('manifesto_geracao.json')).hexdigest()
            bifhash=hashlib.sha256(eva.read(f'referencia_bnrep/{domain}.bif')).hexdigest()
            assert bifhash==evmanifest['sha256_bif']
            if domain in reference_hashes: assert reference_hashes[domain]==bifhash
            reference_hashes[domain]=bifhash
            ref={}
            for r in read_csv(eva,'CPTs_originais_bnRep.csv'):
                ref.setdefault(key(r['no'],json.loads(r['configuracao_pais'])),{})[r['estado']]=float(r['probabilidade_referencia'])
            # Weights are the original evaluator's bnRep inference output, independently
            # checked for normalization by node, not newly inferred in this light runner.
            import ast
            parent_weights={key(r['no'],ast.literal_eval(r['pais'])):float(r['peso_marginal_gold']) for r in read_csv(eva,'metricas_por_linha.csv') if r['condicao']=='controle'}
            assert set(parent_weights)==set(ref)
            for node in {k[0] for k in ref}:
                assert abs(sum(v for k,v in parent_weights.items() if k[0]==node)-1)<1e-6
            configs=json.loads(gen.read('personas_original.json'))
            personas=[p for p in configs['personas'] if p.get('ativo',True)]
            predictions={}
            for execution in manifest['execucoes']:
                assert execution['status']=='concluido'
                b=gen.read(execution['cpt_file'])
                assert hashlib.sha256(b).hexdigest()==execution['sha256_cpt']
                cond=execution['condicao']
                predictions[cond]=decode_cpds(json.loads(b))
                meta=json.loads(gen.read(execution['metadata_file']))
                sources=defaultdict(int); no_anchor_nodes=0
                conf_sources=defaultdict(list)
                for node, md in meta['nodes'].items():
                    pars=md.get('rn_parameters')
                    if pars and pars['n_anchors']==0: no_anchor_nodes+=1
                    for row in md['rows']:
                        k=key(node,row['parents']); sources[row['source']]+=1
                        assert set(row['parents'])==set(md['parents'])
                        assert all(abs(predictions[cond][k][s]-p)<1e-12 for s,p in zip(md['states'],row['distribution']))
                        p=list(ref[k].values()); q=[predictions[cond][k][s] for s in ref[k]]
                        rowkl=kl(p,q); tv=sum(abs(a-b) for a,b in zip(p,q))/2
                        rec=dict(domain=domain,model=model,condition=cond,node=node,parents=json.dumps(dict(k[1]),sort_keys=True),source=row['source'],confidence=row.get('confidence'),CPT_KL_bits=rowkl,TVD=tv,BN_KL_contribution=rowkl*parent_weights[k])
                        confidence.append(rec)
                        for s in ref[k]:
                            if predictions[cond][k][s] in (0.0,1.0):
                                extremes.append(dict(domain=domain,model=model,condition=cond,node=node,parents=rec['parents'],state=s,source=row['source'],confidence=row.get('confidence'),reference=ref[k][s],prediction=predictions[cond][k][s],absolute_error=abs(ref[k][s]-predictions[cond][k][s])))
                routing.append(dict(domain=domain,model=model,condition=cond,root_fullDist=sources['LLM_FULLDIST_ROOT'],conditional_fullDist=sources['LLM_FULLDIST'],ranked_nodes=sources['RANKED_NODES'],fallback_uniform=sources['FALLBACK_UNIFORM'],nodes_without_anchors=no_anchor_nodes))
            individual=dict(predictions)
            persona_predictions={p['id']:predictions[p['id']] for p in personas}
            predictions['ensemble_iguais']=combine(persona_predictions,personas,configs['calibracao'].get('pesos_por_no',{}),True)
            predictions['ensemble_ponderados']=combine(persona_predictions,personas,configs['calibracao'].get('pesos_por_no',{}))
            expected={r['condicao']:r for r in read_csv(eva,'comparacao_geral.csv')}
            max_probability_error=0.0
            for r in read_csv(eva,'erros_por_probabilidade.csv'):
                k=key(r['no'],ast.literal_eval(r['configuracao_pais']))
                assert abs(ref[k][r['estado']]-float(r['probabilidade_referencia']))<1e-12
                err=abs(predictions[r['condicao']][k][r['estado']]-float(r['probabilidade_estimada']))
                max_probability_error=max(max_probability_error,err)
            assert max_probability_error<1e-10
            max_metric_error=0.0
            for cond, pred in predictions.items():
                measured=score(ref,pred,parent_weights)
                for metric,value in measured.items():
                    error=abs(value-float(expected[cond][metric]))
                    max_metric_error=max(max_metric_error,error)
                    assert error<1e-7,(stem,cond,metric,error)
                summary.append(dict(domain=domain,model=model,condition=cond,**measured))
                for node in {k[0] for k in ref}:
                    subref={k:v for k,v in ref.items() if k[0]==node}
                    node_rows.append(dict(domain=domain,model=model,condition=cond,node=node,**score(subref,{k:pred[k] for k in subref},parent_weights)))
            uniform={k:{s:1/len(v) for s in v} for k,v in ref.items()}
            if model=='4b': summary.append(dict(domain=domain,model='none',condition='uniform',**score(ref,uniform,parent_weights)))
            audit.append(dict(domain=domain,model=model,n_individuals=len(individual),n_derived_ensembles=2,n_CPT_rows=len(ref),n_probabilities=sum(map(len,ref.values())),max_probability_error=max_probability_error,max_metric_error=max_metric_error,reference_sha256=bifhash))
    summary.sort(key=lambda r:(r['domain'],r['model'],r['condition']))
    node_rows.sort(key=lambda r:(r['domain'],r['model'],r['condition'],r['node']))
    write_csv(out/'summary.csv',summary)
    write_csv(out/'routing.csv',routing)
    write_csv(out/'by_node.csv',node_rows)
    write_csv(out/'by_row.csv',confidence)
    write_csv(out/'extreme_predictions.csv',extremes)
    write_csv(out/'audit.csv',audit)
    (out/'verification.json').write_text(json.dumps(dict(status='PASS',original_files_verified=len(provenance['files']),individual_networks=16,derived_ensembles=8,independent_repetitions_per_cell=1,probability_comparison='name-aligned raw generation and reconstructed ensembles against evaluator exports',metric_check='MAE, RMSE, TVD, smoothed CPT KL and weighted BN KL',bn_parent_marginals='archived evaluator weights; not independently re-inferred',reference_sha256=reference_hashes),indent=2)+'\n',encoding='utf-8')
    print(f'PASS: {len(provenance["files"])} original checksums, 16 generations, 8 reconstructed ensembles, 24 metric records; outputs in {out}')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=ROOT/'results')
    args=parser.parse_args()
    run(args.output_dir.resolve())
